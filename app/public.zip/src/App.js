import React from 'react';
import ProjectList from './ProjectList';


const App = () => {
return (
<div className="App">
<ProjectList />
</div>
);
};


export default App;
import React, { useState } from 'react';
import HWSet from './HWSet';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

const projectStyle = {
  border: '1px solid #000',
  padding: '40px',
  margin: '40px',
};

const flexRow = {
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
};

const titleStyle = {
  textTransform: 'uppercase',
  letterSpacing: '2px',
  fontWeight: 'bold',
  fontSize: '24px',
};

const usersTitleStyle = {
  textTransform: 'capitalize',
  fontSize: '18px',
};

const Project = ({ name }) => {
  const [hwSetQuantities, setHWSetQuantities] = useState({
    HWSet1: 40,
    HWSet2: 0,
  });

  const [buttonColor, setButtonColor] = useState('red');

  const handleJoinClick = () => {
    // Toggle the button color between 'red' and 'blue'
    setButtonColor((prevColor) => (prevColor === 'red' ? 'blue' : 'red'));
  };

  const handleHWSetCheckOut = (hwSetName, quantity) => {
      setHWSetQuantities(prevQuantities => ({
      ...prevQuantities,
      [hwSetName]: Math.max(prevQuantities[hwSetName] - quantity, 0),
    }));
  };
    

  const handleHWSetCheckIn = (hwSetName, quantity) => {
    setHWSetQuantities(prevQuantities => ({
    ...prevQuantities,
    [hwSetName]: prevQuantities[hwSetName] + quantity,
  }));
};

  return (
    <div style={projectStyle}>
      <div style={flexRow}>
        <div>
          <h2 style={titleStyle}>{name}</h2>
        </div>
        <div style={titleStyle}>
          <h2 style={usersTitleStyle}>Users</h2>
        </div>
        <div style={flexRow}>
          <div>
            <HWSet
              name="HW Set 1"
              quantity={hwSetQuantities.HWSet1}
              capacity={100}
              onCheckIn={handleHWSetCheckIn}
              onCheckOut={handleHWSetCheckOut}
            />
          </div>
          <div>
            <HWSet
              name="HW Set 2"
              quantity={hwSetQuantities.HWSet2}
              capacity={100}
              onCheckIn={handleHWSetCheckIn}
              onCheckOut={handleHWSetCheckOut}
            />
          </div>
        </div>
        <TextField variant="outlined" label="Quantity" />
        <Button
          variant="contained"
          style={{ backgroundColor: buttonColor, color: 'white', fontSize: '20px', fontWeight: 'bold' }}
          onClick={handleJoinClick}
        >
          JOIN
        </Button>
      </div>
    </div>
  );
};

export default Project;
